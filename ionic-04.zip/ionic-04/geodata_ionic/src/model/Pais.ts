export interface Pais {
    name: string;
    abvcod: string;
    capital: string;
    region: string;
    subregion: string;
    demonym: string;
    population: number;
    area: number;
    gini: number;
    latlng: Array<any>;
}
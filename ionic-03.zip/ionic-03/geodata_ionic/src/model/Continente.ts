export interface Continente {
  nome: string;
  valor: string;
}

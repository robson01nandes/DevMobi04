import { Injectable } from '@angular/core';
import { SQLite, SQLiteObject }	from '@ionic-native/sqlite';

/*
  Generated class for the DatabaseProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class DatabaseProvider {

  constructor(public db: SQLite) {
    
  }

  openDatabase() {
    return this.db.create({
      name: "paises.db",
      location: "default"
    });
  }

  createDatabase() {
    return this.openDatabase().
    then((db: SQLiteObject) => {
      this.createTabelaPais(db);
    });
  }

  createTabelaPais(db: SQLiteObject) {
    let sql: string =  "CREATE TABLE IF NOT EXISTS pais (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, abvcod TEXT, capital TEXT, regiao TEXT, subRegiao TEXT, demonimo TEXT, populacao INTEGER, area FLOAT, gini FLOAT, latitude FLOAT, longitude FLOAT)";
    db.executeSql(sql, {});
    console.log("createTabelaPaises");
  }

}

export interface Pais {
  nome: string;
  abvcod: string;
  capital: string;
  regiao: string;
  subRegiao: string;
  demonimo: string;
  populacao: number;
  area: number;
  gini: number;
  latitude: number;
  longitude: number;
}
